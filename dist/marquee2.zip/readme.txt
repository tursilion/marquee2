Just a quick little clone of the Marquee screensaver - except this one will read the lines of text from an external file. It should skip blank lines.

Drop it into \Windows\System32 or \Winnt\system32, depending on which one you have, then it will show up as normal for configuration and the like.

Written by Tursi - www.harmlesslion.com
Slogans.txt provided by Brent Butler - www.brentbutler.com

Version 1.1 - Moved to VS2005, Fixed font color, added randomization
